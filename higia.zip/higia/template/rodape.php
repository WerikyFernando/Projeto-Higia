<footer class="footer-fixo bg-light">
        <font face= "Montserrat">
          <div class="text-center">
          <a href="?pagina=contato"style="color: black"> <h5> Entre em Contato</h5> </a>
        </font>
    </div>
</footer>
</body>
</html>
