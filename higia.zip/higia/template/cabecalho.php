<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Higia</title>
    <link rel="stylesheet" href="libs/css/bootstrap.css">
    <link rel="stylesheet" href="libs/css/projetohigia.css">
  <!-- <link rel="stylesheet" href="../css/bootstrap.css"> -->

  <link href="https://fonts.googleapis.com/css?family=PT+Serif|Source+Serif+Pro&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto|Source+Serif+Pro&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans|Oswald|Source+Serif+Pro&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Quicksand|Source+Serif+Pro&display=swap" rel="stylesheet">
  <script src="libs/js/jquery-3.4.1.js"></script>
  <script src="libs/popper.min.js"></script>


  <script src="libs/js/bootstrap.js"></script>
  <script src="libs/js/jquery.mask.js"></script>
  <script src="libs/js/datables.js"></script>

  <script>
  $(document).ready(function(){
    var SPMaskBehavior = function (val) {
      return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
    },
    spOptions = {
      onKeyPress: function(val, e, field, options) {
        field.mask(SPMaskBehavior.apply({}, arguments), options);
      }
    };

    $('.fone').mask(SPMaskBehavior, spOptions);
    $('.dtns').mask('00/00/0000');
    $('.cpf').mask('000.000.000-00', {reverse: true});
    // $('.table').DataTable();
  });
  </script>

  </head>
   <body background="img/pr.jpg" style="background-repeat: no-repeat" >
