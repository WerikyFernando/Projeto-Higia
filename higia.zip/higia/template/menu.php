
      <div class="col-md mx-auto text-center">
        <div class="row mx-2">
          <a href="?pagina=home.php"> <img src="img/logo.png" alt="" width="250px"></a>
          <div class="col-md pt-2 px-6">
            <div class="text-right">

              <button class="btn btn-info" data-toggle="modal"
              style="width: 100px" data-target="#modalCadastro" name="button">Cadastro</button>

              <button class="btn btn-info" data-toggle="modal"
              style="width: 100px" data-target="#modalLogin" name="button">Login</button>

            </div>
          </div>
          </div>
          </div>

      <div class="col-md">

        <ul class="nav justify-content-center">

          <li class="nav-item">
            <a href="?pagina=procMed"style="color: white">
            <button type="button"class="btn btn-info m-1 ml-3"style="width: 180px"id="btnProcureMedico">
              Procure seu médico
            </button></a>
          </li>

          <li class="nav-item">
            <a href=""style="color: white">
            <button type="button"class="btn btn-info  m-1 ml-3"style="width: 180px" id="btnConsulta">
              Consulta
            </button></a>
          </li>

          <li class="nav-item">
            <a href=""style="color: white">
            <button type="button"class="btn btn-info  m-1 ml-3"style="width: 180px"id="btnAgendamento">
              Agendamento
            </button></a>
          </li>

        </ul>
        <br>
      </div>
