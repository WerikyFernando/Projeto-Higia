<?php
$id_medico = trim($_POST['id_medico']);
$con = conecta();
$res = mysqli_query($con, "SELECT * FROM  medico WHERE id_medico=$id_medico");
$medico = mysqli_fetch_assoc($res);
?>
<div class="col-md-2 mx-auto text-center text-white cabecalho-fixo">
  <h2>EXCLUIR MÉDICO</h2>
</div>

<form action="?pagina=excluirMed" method="post">

  <div class="row p-4 mx-auto text-center">
    <div class="col-md text-center">
      <input placeholder="Senha"type="password" name="senha" value="<?php echo $medico['senha'];?>" class="form-control" style="width: 350px" required="Campo Obrigatório"><br>
      <input placeholder="Confirmar Senha" type="password" name="confsenha" value="" class="form-control" style="width: 350px" required="Campo Obrigatório">
      <input id="id_medico" name="id_medico" value="<?php echo $medico['id_medico'];?>" type="hidden">
      <button class="mt-3 btn btn-danger text-center" style="width: 180px" type="submit">Excluir</button>

    </div>
  </div>

</form>
