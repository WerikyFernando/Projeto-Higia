
<div class="row">
  <div class="col-md-3 mx-auto py-3">

    <div class="text-center text-white">
      <h3>Entre em Contato Conosco</h3>
    </div>
  </div>
</div>

<form action="" method="get">

  <div class="row">
    <div class="col-md-3 mx-auto "style="color:white">

      <label>Nome</label><br>
      <input placeholder="Digite seu nome"type="text" name="nome" value="" class="form-control"><br>
      <label>Email</label><br>
      <input placeholder="Digite seu email"type="text" name="email" value="" class="form-control"><br>
      <label>Telefone</label><br>
      <input placeholder="Digite seu telefone"type="text" name="tel" value="" class="form-control fone"><br>

    </div>
    <div class="col-md-3 mx-auto "style="color:white">
      <label>Assunto</label><br>
      <select id=ass class="browser-defaukt custom-select">
        <option>Selecione uma opção</option>
        <option>Informação</option>
        <option>Solicitação</option>
        <option>Dúvidas</option>
        <option>Sugestões</option>
        <option>Elogios</option>
        <option>Agradecimentos</option>
        <option>Reclamações</option>
        <option>Outros</option>
      </select><br><br>
      <label>Mensagem</label><br>
      <input placeholder="Digite aqui sua mensagem"type="text" name="mensagem" value="" class="form-control"><br>
      <button type="submit" class="mt-3 btn btn-danger">Enviar mensagem</button><br><br>


    </div>

  </div>
</form>
