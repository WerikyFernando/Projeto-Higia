<?php
$id_medico = trim($_POST['id_medico']);
$con = conecta();
$res = mysqli_query($con, "SELECT * FROM  medico WHERE id_medico=$id_medico");
$medico = mysqli_fetch_assoc($res);
?>
<div class="col-md-2 mx-auto text-center text-white cabecalho-fixo">
  <h2>ALTERAR MÉDICO</h2>
</div>

<form action="?pagina=alterarMed" method="post">

  <div class="row p-4 m-4">
    <div class="col-md">
      <input placeholder="Nome" type="text" name="nome" value="<?php echo $medico['nome'];?>" class="form-control"required="Campo Obrigatório"><br>
      <input placeholder="Email"type="email" name="email" value="<?php echo $medico['email'];?>" class="form-control"required="Campo Obrigatório"><br>
      <input placeholder="Data de Nascimento" type="text" name="dtnas" value="<?php echo $medico['dtnas'];?>" class="form-control dtns" required="Campo Obrigatório"><br>
      <input placeholder="RG"type="number" name="rg" value="<?php echo $medico['rg'];?>" class="form-control" required="Campo Obrigatório"><br>

    </div>
    <div class="col-md">
      <input placeholder="CPF"type="text" name="cpf" value="<?php echo $medico['cpf'];?>" class="form-control cpf" required="Campo Obrigatório"><br>

      <select class="form-control" value="<?php echo $medico['areaDeAtuacao'];?>" name="areaDeAtuacao">
        <option value= <?php echo $medico['areaDeAtuacao']; ?>> <?php echo $medico['areaDeAtuacao'] ?></option>
        <option value="Neurocirurgião">Neurocirurgião</option>
        <option value="Oftalmologista">Oftalmologista</option>
        <option value="Dermatologista">Dermatologista</option>
        <option value="Endocrinologista">Endocrinologista</option>
        <option value="Ortopedista">Ortopedista</option>
        <option value="Urologista">Urologista</option>


      </select> <br>
      <input placeholder="Conselho Regional de Medicina" type="text" name="crm" value="<?php echo $medico['crm'];?>" class="form-control CPF" required="Campo Obrigatório"><br>
      <input placeholder="Telefone"type="text" name="telefone" value="<?php echo $medico['telefone'];?>" class="form-control fone"required="Campo Obrigatório"><br>

    </div>
    <div class="col-md">
      <input placeholder="Senha"type="password" name="senha" value="<?php echo $medico['senha'];?>" class="form-control" required="Campo Obrigatório"><br>
      <input placeholder="Confirmar Senha" type="password" name="confsenha" value="" class="form-control" required="Campo Obrigatório">

      <input id="id_medico" name="id_medico" value="<?php echo $medico['id_medico'];?>" type="hidden">
      <button class="mt-3 btn btn-danger text-center" style="width: 180px" type="submit">Alterar</button>

    </div>
  </div>

</form>
