
<div class="col-md-2 mx-auto text-center text-white cabecalho-fixo">
  <h2>CADASTRO MÉDICO</h2>
</div>

<form action="?pagina=salvarMed" method="post">

  <div class="row p-4 m-4">
    <div class="col-md">
      <input placeholder="Nome" type="text" name="nome" value="" class="form-control"required="Campo Obrigatório"><br>
      <input placeholder="Email"type="email" name="email" value="" class="form-control"required="Campo Obrigatório"><br>
      <input placeholder="Data de Nascimento" type="Data" name="dtnas" value="" class="form-control dtns" required="Campo Obrigatório"><br>
      <input placeholder="RG"type="number" name="rg" value="" class="form-control" required="Campo Obrigatório"><br>
    </div>
    <div class="col-md">
      <input placeholder="CPF"type="text" name="cpf" value="" class="form-control cpf" required="Campo Obrigatório"><br>

      <select class="form-control" name="areaDeAtuacao">
        <option value="AA">Area de Atuação</option>
        <option value="Neurocirurgião">Neurocirurgião</option>
        <option value="Oftalmologista">Oftalmologista</option>
        <option value="Dermatologista">Dermatologista</option>
        <option value="Endocrinologista">Endocrinologista</option>
        <option value="Ortopedista">Ortopedista</option>
        <option value="Urologista">Urologista</option>


      </select> <br>
      <input placeholder="Conselho Regional de Medicina" type="text" name="crm" value="" class="form-control CPF" required="Campo Obrigatório"><br>
      <input placeholder="Telefone"type="text" name="telefone" value="" class="form-control fone"required="Campo Obrigatório"><br>

    </div>
    <div class="col-md">
      <input placeholder="Senha"type="password" name="senha" value="" class="form-control" required="Campo Obrigatório"><br>
      <input placeholder="Confirmar Senha" type="password" name="confsenha" value="" class="form-control" required="Campo Obrigatório">

      <button class="mt-3 btn btn-danger text-center" style="width: 180px" type="submit">Cadastrar</button>

    </div>
  </div>

</form>
