
<div class="col-md-2 mx-auto text-center text-white cabecalho-fixo ">
  <h2>CADASTRO PACIENTE</h2>
</div>

<form action="" method="post">

  <div class="row p-4 m-4">
    <div class="col-md">
      <input placeholder="Nome" type="text" name="nome" value="" class="form-control"required="Campo Obrigatório"><br>
      <input placeholder="Email"type="text" name="email" value="" class="form-control"required="Campo Obrigatório"><br>

      <select class="form-control" name="sexo">
        <option value="S">Sexo</option>
        <option value="M">Masculino</option>
        <option value="F">Feminino</option>
        <option value="O">Outro</option>
      </select>

    </div>
    <div class="col-md">
      <input placeholder="RG"type="text" name="rg" value="" class="form-control" required="Campo Obrigatório"><br>
      <input placeholder="CPF"type="text" name="cpf" value="" class="form-control CPF" required="Campo Obrigatório"><br>
      <input placeholder="Data de Nascimento" type="data" name="dtnasc" value="" class="form-control dtns" required="Campo Obrigatório"><br>

    </div>
    <div class="col-md">
      <input placeholder="Telefone"type="text" name="tel" value="" class="form-control fone"required="Campo Obrigatório"><br>
      <input placeholder="Senha"type="password" name="senha" value="" class="form-control" required="Campo Obrigatório"><br>
      <input placeholder="Confirmar Senha" type="password" name="confsenha" value="" class="form-control" required="Campo Obrigatório"><br>

      <button class="mt-3 btn btn-danger text-center" style="width: 180px" type="submit">Cadastrar</button>

    </div>
  </div>

</form>
