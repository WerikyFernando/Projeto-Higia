<?php
//conexão bd
define ('HOST', 'localhost');
define ('USER', 'root');
define ('PASS', '');
define ('BANCO', 'higia');
?>
