<?php
function navega($pagina){
  switch ($pagina) {
    case 'home':
    require 'paginas/home.php';
    break;
    // Casdastros
    case 'cadastroMedico':
    require 'paginas/cadastroMedico.php';
    break;

    case 'cadastroPaciente':
    require 'paginas/cadastroPaciente.php';
    break;
    //contato
    case 'contato':
    require 'paginas/formcontato.php';
    break;

    //bd
    case 'conexao':
    require 'libs/config.php';
    break;

    case 'salvarMed':
    require 'controle/crudMed/salvarMed.php';
    break;
    //menu
    case 'procMed':
    require 'controle/crudMed/buscarMed.php';
    break;

    //altera
    case 'alterarMed':
    require 'controle/crudMed/alterarMed.php';
    break;

    case 'alterarMedico':
    require 'paginas/alterarMedico.php';
    break;
    //exclui
    case 'excluirMedico':
    require 'paginas/excluirMedico.php';
    break;
    
    case 'excluirMed':
    require 'controle/crudMed/excluirMed.php';
    break;


    // default
    default:
    require 'paginas/home.php';
    break;



  }
}
function conecta(){
  return mysqli_connect(HOST, USER, PASS, BANCO);
}
?>
