<?php

$get = isset($_GET['pagina'])? $_GET['pagina']:'';
require 'libs/funcs.php';
require 'libs/config.php';
require 'template/cabecalho.php';
require 'template/menu.php';
require 'paginas/modal/modalcad.php';
require 'paginas/modal/modallogin.php';

navega($get);


require 'template/rodape.php';
 ?>
