
          <div class="col-md mx-auto">
            <div class="text-center" style="color:white">
           <h3>LISTA DE MÉDICOS CADASTRADOS</h3>
         </div>

           <hr>
           <?php
           $con = conecta();
           $select = mysqli_query($con,"SELECT * FROM medico");

           //msqli_query executa o código do banco
              ?>
            <table id="teste" class="table table-striped table-bordered bg-light text-center" style="width:100%"  >
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>CRM</th>
                  <th>E-mail</th>
                  <th>Telefone</th>
                  <th>Área de Atuação</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($array = mysqli_fetch_assoc($select)) {?>
                <!-- mysqli_fetch_assoc cria um array que busca o resultado msqli_query  -->
              <tr>
                <td><?php echo $array['nome']; ?></td>
                <td><?php echo $array['crm']; ?></td>
                <td><?php echo $array['email']; ?></td>
                <td><?php echo $array['telefone']; ?></td>
                <td><?php echo $array['areaDeAtuacao']; ?></td>
                <td>
                  <form class="" action="?pagina=alterarMedico" method="post">
                    <input type="hidden" name='id_medico' value="<?php echo $array['id_medico']; ?>"></input>

                  <button>Alterar</button></td>
                </form>
                <td>
                  <form class="" action="?pagina=excluirMedico" method="post">
                    <input type="hidden" name='id_medico' value="<?php echo $array['id_medico']; ?>"></input>
                  <button>Excluir</button></td>
              </tr>
            <?php } ?>
           </tbody>
            </table>

       </div>
     </div>

     <!-- "Importa" os códigos/bibliotecas javascript -->


      <script>
      $(document).ready( function () {
        $('#teste').DataTable();
      } );
      </script>
