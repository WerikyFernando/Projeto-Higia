<?php
$id_medico = trim($_POST['id_medico']);
$nome = trim($_POST ['nome']);
$rg = trim($_POST ['rg']);
$cpf = trim($_POST ['cpf']);
$dtnas = trim($_POST ['dtnas']);
$crm = trim($_POST ['crm']);
$areaDeAtuacao = trim($_POST ['areaDeAtuacao']);
$email = trim($_POST ['email']);
$telefone = trim($_POST ['telefone']);
$senha = trim($_POST ['senha']);
$confsenha = trim($_POST ['confsenha']);


if ($areaDeAtuacao!="AA" ) {
  if ($senha==$confsenha) {
    $con = conecta();
    $result_medico = "UPDATE medico set nome='$nome', rg='$rg', cpf='$cpf', dtnas='$dtnas', crm='$crm', areaDeAtuacao='$areaDeAtuacao', email='$email', telefone='$telefone', senha='$senha'
    WHERE id_medico=$id_medico";

    $resultado_medico = mysqli_query($con, $result_medico);

  }
}
if ($resultado_medico) {?>
  <div class="col-md-10 mx-auto mt-3 py-4 alert alert-success"style="color:green" role="alert">
        <h4 class="alert-heading">Alterado com sucesso!</h4>
        <hr>
        <p class="mb-0">Clique <b><a href="?pagina=home"style="color:green">aqui</a></b> para fazer login.</a></p>
      </div>

<?php  }
else{?>
  <div class="col-md-10 mx-auto mt-3 py-4 alert alert-danger "style="color:red" role="alert">
  <h4 class="alert-heading">ERRO!</h4>
 <p>Ocorreu um erro na alteração, por favor, contacte o administrador.</p>
 <hr>
 <p class="mb-0">Clique <b><a href='?pagina=home'style="color:red">aqui</a></b> para voltar.</a></p>
</div>
<?php
}?>
