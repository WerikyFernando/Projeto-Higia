<?php
$id_medico = trim($_POST['id_medico']);
$senha = trim($_POST ['senha']);
$confsenha = trim($_POST ['confsenha']);



  if ($senha==$confsenha) {
    $con = conecta();
    $result_medico = "DELETE FROM medico

    WHERE id_medico=$id_medico";
    $resultado_medico = mysqli_query($con, $result_medico);
    if (var_dump($resultado_medico)==1) {?>
      <div class="col-md-10 mx-auto mt-3 py-4 alert alert-success"style="color:green" role="alert">
            <h4 class="alert-heading">Cadastrado com sucesso!</h4>
            <hr>
            <p class="mb-0">Clique <b><a href="?pagina=home"style="color:green">aqui</a></b> para fazer login.</a></p>
          </div>
    <?php}
    else{ ?>
      <div class="col-md-10 mx-auto mt-3 py-4 alert alert-danger "style="color:red" role="alert">
      <h4 class="alert-heading">ERRO!</h4>
      <p>Ocorreu um erro ao excluir sua conta, por favor, contacte o administrador.</p>
      <hr>
      <p class="mb-0">Clique <b><a href='?pagina=home'style="color:red">aqui</a></b> para voltar.</a></p>
      </div>
    <?php  }
}  else{
  echo ("Senha errada!");
}?>
