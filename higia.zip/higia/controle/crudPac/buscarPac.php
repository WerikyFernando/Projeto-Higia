
          <div class="col-md mx-auto">
            <div class="text-center" style="color:white">
           <h3>LISTA DE PACIENTES CADASTRADOS</h3>
         </div>

           <hr>
           <?php
           $con = conecta();
           $select = mysqli_query($con,"SELECT * FROM paciente");

           //msqli_query executa o código do banco
              ?>
            <table id="teste" class="table table-striped table-bordered bg-light text-center" style="width:100%"  >
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>RG</th>
                  <th>CPF</th>
                  <th>E-mail</th>
                  <th>Telefone</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($array = mysqli_fetch_assoc($select)) {?>
                <!-- mysqli_fetch_assoc cria um array que busca o resultado msqli_query  -->
              <tr>
                <td><?php echo $array['nome']; ?></td>
                <td><?php echo $array['rg']; ?></td>
                <td><?php echo $array['cpf']; ?></td>
                <td><?php echo $array['email']; ?></td>
                <td><?php echo $array['telefone']; ?></td>
                <td>
                  <form class="" action="?pagina=" method="post">
                    <input type="hidden" name='id_medico' value="<?php echo $array['id_medico']; ?>"></input>

                  <button>Alterar</button></td>
                </form>
                <td>
                  <form class="" action="?pagina=" method="post">
                    <input type="hidden" name='id_medico' value="<?php echo $array['id_medico']; ?>"></input>
                  <button>Excluir</button></td>
              </tr>
            <?php } ?>
           </tbody>
            </table>

       </div>
     </div>

     <!-- "Importa" os códigos/bibliotecas javascript -->


      <script>
      $(document).ready( function () {
        $('#teste').DataTable();
      } );
      </script>
