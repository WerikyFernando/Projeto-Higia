<?php
$nome = trim($_POST ['nome']);
$email = trim($_POST ['email']);
$rg = trim($_POST ['rg']);
$cpf = trim($_POST ['cpf']);
$dtnas = trim($_POST ['dtnasc']);
$telefone = trim($_POST ['tel']);
$sexo = trim($_POST ['sexo']);
$senha = trim($_POST ['senha']);
$confsenha = trim($_POST ['confsenha']);


if ($sexo!="S") {
  if ($confsenha==$senha){
    $result_paciente = "INSERT INTO paciente (nome, email, rg, cpf, dtnas, telefone, sexo, senha)
    VALUES ('$nome','$email','$rg', '$cpf', '$dtnas', '$telefone', '$sexo',MD5('$senha'))";
    $con = conecta();
    $resultado_paciente = mysqli_query($con, $result_paciente);
  }
}

if ($resultado_paciente) {
  header('salvar');
}
else{
  echo "ERRO";
}


?>
